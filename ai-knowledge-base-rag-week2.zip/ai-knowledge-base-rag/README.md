# AI-Powered Knowledge Base (Week 2)

A Retrieval-Augmented Generation (RAG) application built with Python, LangChain, ChromaDB, OpenAI, and Streamlit.

Upload PDF research papers or company documents, index their content into a persistent vector database, and ask questions. Answers are grounded in retrieved document passages and display source file names and page numbers.

## Features

- Upload one or multiple PDF files.
- Extract PDF text and preserve page metadata.
- Split documents into configurable overlapping chunks.
- Generate embeddings using OpenAI `text-embedding-3-small`.
- Store and search vectors using persistent ChromaDB.
- Retrieve the most relevant chunks for each question.
- Generate grounded answers using a LangChain prompt and OpenAI chat model.
- Display source citations with document name, page number, and excerpt.
- Detect duplicate uploads using SHA-256 file hashes.
- Clear chat history.
- Configure chunk size, overlap, top-k retrieval, and chat model.

## Architecture

```text
PDF documents
     |
     v
PyPDFLoader (extract text + page metadata)
     |
     v
RecursiveCharacterTextSplitter
     |
     v
OpenAI Embeddings (text-embedding-3-small)
     |
     v
ChromaDB (persistent vector store)
     |
User question
     |
     v
OpenAI Embeddings -> similarity search (top-k chunks)
     |
     v
LangChain prompt + retrieved context
     |
     v
OpenAI Chat Model
     |
     v
Grounded answer + source file/page citations
```

## Project structure

```text
ai-knowledge-base-rag/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
└── data/
    ├── chroma_db/       # Created/used locally; excluded from Git
    └── uploads/         # Reserved for local uploaded files
```

## Requirements

- Python 3.10 or newer
- OpenAI API key with access to an embeddings model and chat model
- Internet connection
- Text-based PDF files (scanned PDFs need OCR first)

API calls may incur charges. A ChatGPT subscription does not automatically include OpenAI API credits.

## Setup and run

### 1. Clone your repository

```bash
git clone <your-github-repository-url>
cd ai-knowledge-base-rag
```

### 2. Create a virtual environment

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

macOS / Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Configure your API key

Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

macOS / Linux:

```bash
cp .env.example .env
```

Edit `.env`:

```env
OPENAI_API_KEY=your_real_api_key
```

Never commit `.env` or publish your API key. `.gitignore` excludes it.

Create an API key at: https://platform.openai.com/api-keys

### 5. Start the application

```bash
streamlit run app.py
```

Open the local URL shown in the terminal, normally `http://localhost:8501`.

## How to use

1. Enter your OpenAI API key in the sidebar or configure `.env`.
2. Open **Upload & index PDFs**.
3. Select one or more PDF research papers or company documents.
4. Adjust chunk size and overlap if needed.
5. Click **Ingest selected PDFs** and wait for indexing to finish.
6. Open **Ask the knowledge base**.
7. Ask a question based on the uploaded documents.
8. Read the answer and expand **Sources used** to inspect the supporting file, page, and excerpt.

## RAG concepts demonstrated

- **Ingestion:** Reading source documents and extracting text.
- **Chunking:** Splitting long documents into smaller passages.
- **Embeddings:** Converting text into vectors for semantic search.
- **Vector database:** Persisting and retrieving embeddings in ChromaDB.
- **Retrieval:** Finding the top-k passages relevant to a question.
- **Augmented generation:** Passing retrieved passages into the LLM prompt.
- **Grounding:** Instructing the model to answer only from supplied context.
- **Citations:** Showing source document names and page numbers.

## Troubleshooting

- **401 / invalid API key:** Check your key and confirm it is available to the selected OpenAI account.
- **Insufficient quota / billing:** Check API billing and usage. ChatGPT Plus/Free access is separate from API billing.
- **Model not found:** Change the chat model in the sidebar to a model enabled for your API account.
- **No text extracted:** The PDF may be scanned or image-only. OCR it first, then upload the searchable PDF.
- **No relevant answer:** Confirm PDFs were ingested, ask a more specific question, or increase top-k.
- **Import errors:** Activate the virtual environment and reinstall with `pip install -r requirements.txt`.
- **Chroma database issue:** Stop Streamlit and, if you are comfortable rebuilding the index, remove the local `data/chroma_db` folder and ingest the PDFs again. This deletes the local vector index.

## Git submission

The local Chroma database and API key are excluded from Git. You should commit the source code and documentation:

```bash
git status
git add app.py requirements.txt README.md .env.example .gitignore
git commit -m "Build PDF RAG knowledge base with LangChain and ChromaDB"
git push
```

Do not commit `.env`, API keys, private company documents, or the local Chroma database.

## Suggested demo for your submission

For a safe demonstration, use a public research paper or a sample PDF that you are allowed to share. Capture screenshots of:
1. The PDF upload and successful ingestion.
2. The indexed document list and chunk count.
3. A question and grounded answer.
4. The expanded source citations showing document name and page number.
