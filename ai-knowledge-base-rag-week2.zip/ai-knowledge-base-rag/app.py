import hashlib
import os
import tempfile
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv
from langchain_chroma import Chroma
from langchain_community.document_loaders import PyPDFLoader
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = DATA_DIR / "uploads"
CHROMA_DIR = DATA_DIR / "chroma_db"
COLLECTION_NAME = "week2_knowledge_base"

for folder in (DATA_DIR, UPLOAD_DIR, CHROMA_DIR):
    folder.mkdir(parents=True, exist_ok=True)

st.set_page_config(
    page_title="AI Knowledge Base",
    page_icon="📚",
    layout="wide",
)

SYSTEM_PROMPT = """You are a careful knowledge-base assistant.
Answer the user's question using ONLY the supplied document context.
If the context does not contain enough information, say:
"I couldn't find enough information in the uploaded documents to answer that."
Do not invent facts or citations.
When you make a factual claim, cite the supporting source using the source
labels provided in the context, for example [Source 1, page 4].
If sources disagree, explain the disagreement and cite both.
Be clear, concise, and directly answer the question.

DOCUMENT CONTEXT:
{context}
"""

def file_sha256(file_bytes: bytes) -> str:
    return hashlib.sha256(file_bytes).hexdigest()


def get_vectorstore(api_key: str) -> Chroma:
    embeddings = OpenAIEmbeddings(
        model="text-embedding-3-small",
        api_key=api_key,
    )
    return Chroma(
        collection_name=COLLECTION_NAME,
        embedding_function=embeddings,
        persist_directory=str(CHROMA_DIR),
    )


def load_pdf_documents(pdf_bytes: bytes, original_name: str, digest: str):
    # PyPDFLoader expects a filesystem path, so write the upload to a temporary file.
    suffix = Path(original_name).suffix or ".pdf"
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as temp_file:
            temp_file.write(pdf_bytes)
            temp_path = temp_file.name

        loader = PyPDFLoader(temp_path)
        pages = loader.load()

        for page in pages:
            page.metadata["source"] = original_name
            page.metadata["file_hash"] = digest
            # PyPDFLoader page metadata uses zero-based page numbers.
            page.metadata["page_number"] = int(page.metadata.get("page", 0)) + 1
        return pages
    finally:
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)


def ingest_pdfs(uploaded_files, api_key: str, chunk_size: int, chunk_overlap: int):
    vectorstore = get_vectorstore(api_key)
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", ". ", " ", ""],
    )

    already_ingested = set()
    try:
        existing = vectorstore.get(include=["metadatas"])
        for metadata in existing.get("metadatas", []) or []:
            if metadata and metadata.get("file_hash"):
                already_ingested.add(metadata["file_hash"])
    except Exception:
        # A new or empty Chroma collection may have no records yet.
        pass

    added_files = []
    skipped_files = []
    total_chunks = 0
    errors = []

    for uploaded in uploaded_files:
        pdf_bytes = uploaded.getvalue()
        digest = file_sha256(pdf_bytes)

        if digest in already_ingested:
            skipped_files.append(uploaded.name)
            continue

        try:
            pages = load_pdf_documents(pdf_bytes, uploaded.name, digest)
            if not pages:
                errors.append(f"{uploaded.name}: no readable pages found.")
                continue

            chunks = splitter.split_documents(pages)
            if not chunks:
                errors.append(f"{uploaded.name}: no extractable text found.")
                continue

            vectorstore.add_documents(chunks)
            added_files.append(uploaded.name)
            total_chunks += len(chunks)
            already_ingested.add(digest)
        except Exception as exc:
            errors.append(f"{uploaded.name}: {exc}")

    return added_files, skipped_files, total_chunks, errors


def answer_question(question: str, api_key: str, model: str, k: int):
    vectorstore = get_vectorstore(api_key)
    retriever = vectorstore.as_retriever(search_kwargs={"k": k})
    retrieved_docs = retriever.invoke(question)

    if not retrieved_docs:
        return (
            "I couldn't find any relevant content. Upload and ingest PDF documents first.",
            [],
        )

    context_parts = []
    for index, doc in enumerate(retrieved_docs, start=1):
        source = Path(str(doc.metadata.get("source", "Unknown document"))).name
        page = doc.metadata.get("page_number", doc.metadata.get("page", "N/A"))
        context_parts.append(
            f"[Source {index}: {source}, page {page}]\n{doc.page_content}"
        )

    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", SYSTEM_PROMPT),
            ("human", "{question}"),
        ]
    )
    llm = ChatOpenAI(
        model=model,
        temperature=0.1,
        api_key=api_key,
    )
    chain = prompt | llm
    response = chain.invoke(
        {
            "context": "\n\n---\n\n".join(context_parts),
            "question": question,
        }
    )

    sources = []
    seen = set()
    for index, doc in enumerate(retrieved_docs, start=1):
        source = Path(str(doc.metadata.get("source", "Unknown document"))).name
        page = doc.metadata.get("page_number", doc.metadata.get("page", "N/A"))
        key = (source, page)
        if key not in seen:
            seen.add(key)
            sources.append(
                {
                    "label": f"Source {index}",
                    "file": source,
                    "page": page,
                    "excerpt": doc.page_content[:700].strip(),
                }
            )

    return response.content if isinstance(response.content, str) else str(response.content), sources


def get_document_summary(api_key: str):
    vectorstore = get_vectorstore(api_key)
    try:
        result = vectorstore.get(include=["metadatas"])
        metadatas = result.get("metadatas", []) or []
    except Exception:
        metadatas = []

    docs = {}
    for metadata in metadatas:
        if not metadata:
            continue
        source = metadata.get("source", "Unknown document")
        docs[source] = docs.get(source, 0) + 1
    return docs, sum(docs.values())


st.title("📚 AI-Powered Knowledge Base")
st.caption("Upload PDF documents, build a searchable knowledge base, and ask questions with source citations.")

with st.sidebar:
    st.header("⚙️ Configuration")
    api_key = st.text_input(
        "OpenAI API key",
        value=os.getenv("OPENAI_API_KEY", ""),
        type="password",
        help="You need an OpenAI API key for embeddings and chat responses.",
    )
    model = st.text_input("Chat model", value="gpt-4.1-mini")
    st.divider()
    st.subheader("Chunking settings")
    chunk_size = st.slider("Chunk size", 300, 2000, 1000, 100)
    chunk_overlap = st.slider("Chunk overlap", 0, 400, 150, 25)
    top_k = st.slider("Retrieved chunks (top-k)", 1, 10, 4)
    st.caption("Chunk size and overlap apply when new PDFs are ingested.")
    st.divider()
    st.warning("API usage may incur charges. Keep your API key private.")

tab_upload, tab_chat = st.tabs(["📄 Upload & index PDFs", "💬 Ask the knowledge base"])

with tab_upload:
    st.subheader("Upload research papers or company documents")
    uploaded_files = st.file_uploader(
        "Choose one or more PDF files",
        type=["pdf"],
        accept_multiple_files=True,
        help="Text-based PDFs work best. Scanned PDFs may require OCR before ingestion.",
    )

    col1, col2 = st.columns([1, 1])
    with col1:
        ingest_clicked = st.button(
            "🔎 Ingest selected PDFs",
            type="primary",
            use_container_width=True,
            disabled=not uploaded_files,
        )
    with col2:
        refresh_clicked = st.button("↻ Refresh document list", use_container_width=True)

    if ingest_clicked:
        if not api_key.strip():
            st.error("Enter your OpenAI API key in the sidebar before ingesting PDFs.")
        else:
            with st.spinner("Reading PDFs, splitting text, creating embeddings, and saving to ChromaDB..."):
                added, skipped, chunk_count, errors = ingest_pdfs(
                    uploaded_files, api_key.strip(), chunk_size, chunk_overlap
                )
            if added:
                st.success(f"Added {len(added)} PDF(s) and indexed {chunk_count} text chunks.")
                for name in added:
                    st.write(f"✅ {name}")
            if skipped:
                st.info("Skipped already-ingested PDF(s): " + ", ".join(skipped))
            for error in errors:
                st.error(error)
            st.rerun()

    if not api_key.strip():
        st.info("Enter your OpenAI API key to view the indexed document inventory.")
    else:
        try:
            docs, total_chunks = get_document_summary(api_key.strip())
            st.markdown("### Indexed knowledge base")
            if docs:
                st.write(f"**{len(docs)} document(s)** • **{total_chunks} indexed chunks**")
                for name, count in sorted(docs.items()):
                    st.write(f"📄 **{name}** — {count} chunks")
            else:
                st.info("No PDFs indexed yet. Upload PDF files and click Ingest.")
        except Exception as exc:
            st.error(f"Could not read ChromaDB collection: {exc}")

    st.markdown("---")
    st.caption(
        "Note: this starter project extracts selectable PDF text. If a PDF is a scanned image, "
        "run OCR on it first. Re-uploading the exact same PDF is detected by file hash."
    )

with tab_chat:
    st.subheader("Chat with your uploaded documents")
    st.write("Ask a question that can be answered from the PDFs you have indexed.")

    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    for item in st.session_state.chat_history:
        with st.chat_message(item["role"]):
            st.markdown(item["content"])
            if item.get("sources"):
                with st.expander("📌 Sources used"):
                    for source in item["sources"]:
                        st.markdown(
                            f"**{source['label']} — {source['file']} (page {source['page']})**"
                        )
                        st.caption(source["excerpt"])

    question = st.chat_input("Ask a question about your uploaded PDFs...")
    if question:
        if not api_key.strip():
            st.error("Enter your OpenAI API key in the sidebar.")
        else:
            st.session_state.chat_history.append(
                {"role": "user", "content": question}
            )
            with st.chat_message("user"):
                st.markdown(question)

            with st.chat_message("assistant"):
                with st.spinner("Searching your documents and preparing an answer..."):
                    try:
                        answer, sources = answer_question(
                            question, api_key.strip(), model.strip(), top_k
                        )
                        st.markdown(answer)
                        if sources:
                            with st.expander("📌 Sources used", expanded=True):
                                for source in sources:
                                    st.markdown(
                                        f"**{source['label']} — {source['file']} (page {source['page']})**"
                                    )
                                    st.caption(source["excerpt"])
                        st.session_state.chat_history.append(
                            {
                                "role": "assistant",
                                "content": answer,
                                "sources": sources,
                            }
                        )
                    except Exception as exc:
                        error_message = f"Sorry, I couldn't process that question: {exc}"
                        st.error(error_message)
                        st.session_state.chat_history.append(
                            {"role": "assistant", "content": error_message, "sources": []}
                        )

    if st.session_state.chat_history:
        if st.button("Clear chat history"):
            st.session_state.chat_history = []
            st.rerun()

st.divider()
st.caption("Built with Python • LangChain • ChromaDB • OpenAI • Streamlit")
