import os
from datetime import datetime

import streamlit as st
from dotenv import load_dotenv

load_dotenv()

st.set_page_config(
    page_title="AI Writing Assistant",
    page_icon="✍️",
    layout="wide",
    initial_sidebar_state="expanded",
)

TEMPLATES = {
    "Blog Writing": {
        "description": "Create structured, reader-friendly blog articles.",
        "system": (
            "You are an expert blog writer and editor. Write original, useful, "
            "well-structured content. Use a clear title, engaging introduction, "
            "logical headings, practical examples, and a concise conclusion. "
            "Avoid unsupported claims and unnecessary filler."
        ),
        "hint": "Example: Benefits of automation for small businesses",
        "label": "Blog topic / brief",
    },
    "Email Drafting": {
        "description": "Draft clear and professional emails.",
        "system": (
            "You are a professional business communication assistant. Draft an "
            "email appropriate to the requested audience and purpose. Include a "
            "useful subject line, greeting, concise body, and polite sign-off. "
            "Do not invent names, dates, or facts."
        ),
        "hint": "Example: Request two days of leave for a family commitment",
        "label": "Email purpose and key details",
    },
    "Code Explanation": {
        "description": "Explain code, its logic, and important details.",
        "system": (
            "You are a patient senior software engineer and technical educator. "
            "Explain the supplied code accurately. Cover its purpose, flow, "
            "important functions, inputs/outputs, dependencies, and potential "
            "edge cases. Use small examples where useful. Do not claim code was run."
        ),
        "hint": "Paste code and mention your preferred explanation level.",
        "label": "Code / question",
    },
    "Social Media Post": {
        "description": "Create engaging posts for social platforms.",
        "system": (
            "You are a social media content strategist. Create platform-appropriate "
            "copy with a strong opening, readable structure, and a clear call to "
            "action when suitable. Use relevant hashtags sparingly. Avoid fake "
            "statistics and engagement bait."
        ),
        "hint": "Example: Announce the launch of our new productivity app on LinkedIn",
        "label": "Platform, topic, audience, and key message",
    },
}

def generate_openai(api_key: str, model: str, system_prompt: str,
                    user_prompt: str, temperature: float) -> str:
    from openai import OpenAI

    client = OpenAI(api_key=api_key)
    response = client.responses.create(
        model=model,
        instructions=system_prompt,
        input=user_prompt,
        temperature=temperature,
    )
    return response.output_text.strip()


def generate_gemini(api_key: str, model: str, system_prompt: str,
                    user_prompt: str, temperature: float) -> str:
    from google import genai
    from google.genai import types

    client = genai.Client(api_key=api_key)
    response = client.models.generate_content(
        model=model,
        contents=user_prompt,
        config=types.GenerateContentConfig(
            system_instruction=system_prompt,
            temperature=temperature,
        ),
    )
    result = response.text
    if not result:
        raise RuntimeError("The Gemini API returned an empty response.")
    return result.strip()


def format_output(text: str, output_format: str) -> str:
    if output_format == "Plain text":
        # Keep the generated content readable without Markdown markers.
        import re
        text = re.sub(r"^\s{0,3}#{1,6}\s*", "", text, flags=re.MULTILINE)
        text = re.sub(r"\*\*(.*?)\*\*", r"\1", text)
        text = re.sub(r"(?<!\*)\*(?!\*)(.*?)\*(?!\*)", r"\1", text)
        return text
    if output_format == "HTML":
        import markdown
        return markdown.markdown(text, extensions=["extra", "sane_lists"])
    return text


st.title("✍️ AI Writing Assistant")
st.caption("One workspace for blogs, emails, code explanations, and social content.")

with st.sidebar:
    st.header("⚙️ Model settings")
    provider = st.selectbox("AI provider", ["OpenAI", "Gemini"])
    if provider == "OpenAI":
        default_model = "gpt-4.1-mini"
        env_key = "OPENAI_API_KEY"
        model_help = "Example model: gpt-4.1-mini"
    else:
        default_model = "gemini-2.5-flash"
        env_key = "GEMINI_API_KEY"
        model_help = "Example model: gemini-2.5-flash"

    api_key = st.text_input(
        f"{provider} API key",
        value=os.getenv(env_key, ""),
        type="password",
        help=f"Stored in your local .env file or entered for this session. {model_help}",
    )
    model = st.text_input("Model name", value=default_model)
    temperature = st.slider(
        "Temperature",
        min_value=0.0,
        max_value=2.0,
        value=0.7,
        step=0.1,
        help="Lower values are more focused; higher values are more varied. "
             "Some models may restrict supported temperature values.",
    )
    output_format = st.selectbox(
        "Output format", ["Markdown", "Plain text", "HTML"]
    )
    st.divider()
    st.caption("Your API key is used for requests from this app. Never commit it to Git.")

left, right = st.columns([1, 1], gap="large")

with left:
    st.subheader("1. Create your content")
    template_name = st.selectbox("Writing task", list(TEMPLATES.keys()))
    template = TEMPLATES[template_name]
    st.caption(template["description"])

    user_text = st.text_area(
        template["label"],
        height=230,
        placeholder=template["hint"],
    )
    audience = st.text_input("Target audience (optional)")
    tone = st.selectbox(
        "Tone",
        ["Professional", "Friendly", "Informative", "Persuasive", "Casual", "Technical"],
    )
    length = st.selectbox("Length", ["Short", "Medium", "Detailed"])
    extra_instructions = st.text_area(
        "Additional instructions (optional)",
        height=90,
        placeholder="Add keywords, structure, language, formatting, or other requirements...",
    )
    generate = st.button("✨ Generate content", type="primary", use_container_width=True)

with right:
    st.subheader("2. Your generated result")
    if "generated_text" not in st.session_state:
        st.session_state.generated_text = ""
    if "last_format" not in st.session_state:
        st.session_state.last_format = "Markdown"

    if generate:
        if not api_key.strip():
            st.error(f"Enter your {provider} API key in the sidebar or add it to your .env file.")
        elif not user_text.strip():
            st.warning("Enter a topic, email brief, or code before generating.")
        else:
            system_prompt = (
                template["system"]
                + f"\n\nUse a {tone.lower()} tone. Target audience: "
                + (audience.strip() or "general audience")
                + f". Desired length: {length.lower()}."
            )
            if extra_instructions.strip():
                system_prompt += "\nAdditional instructions: " + extra_instructions.strip()

            with st.spinner(f"Generating with {provider}..."):
                try:
                    if provider == "OpenAI":
                        result = generate_openai(
                            api_key.strip(), model.strip(), system_prompt,
                            user_text.strip(), temperature
                        )
                    else:
                        result = generate_gemini(
                            api_key.strip(), model.strip(), system_prompt,
                            user_text.strip(), temperature
                        )
                    st.session_state.generated_text = result
                    st.session_state.last_format = output_format
                    st.success("Content generated successfully.")
                except ImportError as exc:
                    st.error(f"Missing dependency: {exc}. Install packages from requirements.txt.")
                except Exception as exc:
                    st.error(f"Generation failed: {exc}")

    if st.session_state.generated_text:
        rendered = format_output(st.session_state.generated_text, output_format)
        if output_format == "HTML":
            st.code(rendered, language="html")
            st.markdown("**HTML preview**")
            st.components.v1.html(rendered, height=420, scrolling=True)
        elif output_format == "Markdown":
            st.markdown(rendered)
        else:
            st.text(rendered)

        extension = {"Markdown": "md", "Plain text": "txt", "HTML": "html"}[output_format]
        st.download_button(
            "⬇️ Download result",
            data=rendered,
            file_name=f"ai_writing_result.{extension}",
            mime={"Markdown": "text/markdown", "Plain text": "text/plain", "HTML": "text/html"}[output_format],
            use_container_width=True,
        )
        if st.button("Clear result", use_container_width=True):
            st.session_state.generated_text = ""
            st.rerun()
    else:
        st.info("Your result will appear here after you generate content.")

st.divider()
st.caption("Built with Streamlit • OpenAI Responses API • Google Gemini API")
