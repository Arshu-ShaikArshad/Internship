# AI Writing Assistant

A Python + Streamlit app that uses the OpenAI API or Google Gemini API to generate:

- Blog articles
- Professional email drafts
- Code explanations
- Social media posts

## Features

- Choose OpenAI or Gemini as the provider.
- Configure the model name.
- Adjust temperature from 0.0 to 2.0.
- Select a writing template, tone, audience, and desired length.
- Add custom instructions.
- Display output as Markdown, plain text, or HTML.
- Preview HTML and download the generated result.
- API keys are entered locally or loaded from environment variables.

## Requirements

- Python 3.10 or newer
- An OpenAI API key and/or Gemini API key
- Internet connection

API usage may incur charges depending on your provider and account. ChatGPT subscriptions do not automatically include OpenAI API credits.

## Setup

### 1. Clone the repository

```bash
git clone <your-git-repository-url>
cd ai-writing-assistant
```

### 2. Create and activate a virtual environment

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

macOS / Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure API keys

Copy `.env.example` to `.env` and add your key(s).

Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

macOS / Linux:

```bash
cp .env.example .env
```

Open `.env` and replace the placeholder values. You can also paste a key directly into the app's password field in the sidebar.

**Never commit `.env` or share your API keys.** The `.gitignore` file excludes it.

Get API keys:
- OpenAI: https://platform.openai.com/api-keys
- Gemini: https://aistudio.google.com/app/apikey

### 5. Run the app

```bash
streamlit run app.py
```

Streamlit will print a local address, usually `http://localhost:8501`. Open it in your browser.

## How to use

1. Select the AI provider in the sidebar.
2. Enter the provider API key and choose a model.
3. Set the temperature.
4. Select one of the four writing tasks.
5. Enter the topic, email brief, or code.
6. Optionally set audience, tone, length, and extra instructions.
7. Choose the output format and click **Generate content**.
8. Download the result if required.

## Project structure

```text
ai-writing-assistant/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
└── README.md
```

## Troubleshooting

- **Invalid API key:** Check that the key belongs to the selected provider and has not been revoked.
- **Model not found:** Confirm the model name is available to your API account.
- **Rate limit / quota error:** Check your provider's API usage and billing limits.
- **Temperature error:** Some models do not support custom temperature values. Choose a model that supports it or set the temperature to the model's default.
- **Module not found:** Activate the virtual environment and run `pip install -r requirements.txt` again.

## Git submission

Before pushing, check that `.env` is not staged:

```bash
git status
git add app.py requirements.txt README.md .env.example .gitignore
git commit -m "Build AI writing assistant with OpenAI and Gemini"
git push
```

Do not add your real `.env` file or API keys to Git.
