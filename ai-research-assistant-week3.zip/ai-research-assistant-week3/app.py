import os
import json
from datetime import datetime, timezone
from typing import Any

import gradio as gr
import requests
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

OPENAI_MODEL_DEFAULT = "gpt-4.1-mini"
TAVILY_ENDPOINT = "https://api.tavily.com/search"


# ---------------------------
# Agent 1: Web Research Agent
# ---------------------------
def web_research_agent(topic: str, tavily_api_key: str, max_results: int) -> list[dict[str, Any]]:
    """Search the public web and return source records with URLs and snippets."""
    payload = {
        "api_key": tavily_api_key,
        "query": topic,
        "search_depth": "advanced",
        "topic": "general",
        "max_results": max_results,
        "include_answer": False,
        "include_raw_content": False,
    }
    response = requests.post(TAVILY_ENDPOINT, json=payload, timeout=45)
    response.raise_for_status()
    data = response.json()

    results = []
    for item in data.get("results", []):
        results.append({
            "title": item.get("title") or "Untitled source",
            "url": item.get("url") or "",
            "content": item.get("content") or "",
            "score": item.get("score"),
            "published_date": item.get("published_date"),
        })
    return results


# --------------------------------
# Shared helper for LLM-based agents
# --------------------------------
def call_openai_agent(
    client: OpenAI,
    model: str,
    agent_name: str,
    instructions: str,
    user_input: str,
    temperature: float = 0.2,
) -> str:
    """Run one specialized agent using the OpenAI Responses API."""
    response = client.responses.create(
        model=model,
        instructions=instructions,
        input=user_input,
        temperature=temperature,
    )
    output = (response.output_text or "").strip()
    if not output:
        raise RuntimeError(f"{agent_name} returned an empty response.")
    return output


# -------------------------------
# Agent 2: Findings Summarizer
# -------------------------------
def summarization_agent(
    client: OpenAI,
    model: str,
    topic: str,
    sources: list[dict[str, Any]],
) -> str:
    source_text = []
    for index, source in enumerate(sources, start=1):
        source_text.append(
            f"[Source {index}]\n"
            f"Title: {source['title']}\n"
            f"URL: {source['url']}\n"
            f"Published: {source.get('published_date') or 'Not provided'}\n"
            f"Search snippet: {source['content']}"
        )

    instructions = """You are the Findings Summarizer Agent in a multi-agent research workflow.
Synthesize the supplied web search results into a concise, accurate research brief.
Use only information present in the supplied source records. Do not invent facts,
statistics, quotations, dates, or source details. Clearly distinguish established
findings from uncertainty. Identify themes, useful evidence, disagreements, and
information gaps. Attach inline source labels such as [Source 1] to factual claims.
If evidence is weak or snippets are insufficient, say so explicitly.
Return readable Markdown with these headings:
## Executive summary
## Key findings
## Areas of agreement or disagreement
## Evidence gaps and limitations
## Sources (numbered list with title and URL)
"""
    return call_openai_agent(
        client,
        model,
        "Findings Summarizer Agent",
        instructions,
        f"Research topic: {topic}\n\nWeb search records:\n\n" + "\n\n---\n\n".join(source_text),
        temperature=0.2,
    )


# ---------------------------------
# Agent 3: Structured Report Writer
# ---------------------------------
def report_generation_agent(
    client: OpenAI,
    model: str,
    topic: str,
    summary: str,
    report_length: str,
) -> str:
    instructions = f"""You are the Research Report Writer Agent.
Create a polished, structured research report based on the research brief provided.
The requested depth is: {report_length}.
Use only the brief and its cited sources. Preserve source labels like [Source 1]
next to supported claims. Never invent citations, URLs, statistics, or facts.
Make uncertainty and evidence limitations visible. Do not present search snippets
as if you independently verified the full articles.
Use Markdown and include:
# Research Report: [topic]
## 1. Executive Summary
## 2. Research Scope and Approach
## 3. Key Findings
## 4. Analysis and Implications
## 5. Risks, Disagreements, and Evidence Gaps
## 6. Conclusions
## 7. Sources
Include a numbered source list with the URLs supplied in the brief.
"""
    return call_openai_agent(
        client,
        model,
        "Research Report Writer Agent",
        instructions,
        f"Research topic: {topic}\nRequested report depth: {report_length}\n\nResearch brief:\n{summary}",
        temperature=0.3,
    )


def run_research(
    topic: str,
    openai_api_key: str,
    tavily_api_key: str,
    model: str,
    max_results: int,
    report_length: str,
    progress=gr.Progress(),
):
    """Orchestrate the three agents and return report, summary, and source list."""
    topic = (topic or "").strip()
    if not topic:
        raise gr.Error("Enter a research topic or question.")
    if not openai_api_key.strip():
        raise gr.Error("Enter your OpenAI API key.")
    if not tavily_api_key.strip():
        raise gr.Error("Enter your Tavily API key.")

    client = OpenAI(api_key=openai_api_key.strip())

    progress(0.08, desc="Agent 1/3: Searching the web...")
    sources = web_research_agent(topic, tavily_api_key.strip(), int(max_results))
    if not sources:
        raise gr.Error("The web search returned no results. Try a broader research topic.")

    progress(0.38, desc=f"Agent 2/3: Summarizing {len(sources)} sources...")
    summary = summarization_agent(client, model.strip(), topic, sources)

    progress(0.70, desc="Agent 3/3: Writing the structured report...")
    report = report_generation_agent(
        client, model.strip(), topic, summary, report_length
    )

    progress(1.0, desc="Research report complete.")
    source_markdown = "\n".join(
        f"{i}. [{s['title']}]({s['url']})"
        + (f" — Published: {s['published_date']}" if s.get("published_date") else "")
        for i, s in enumerate(sources, start=1)
    )
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    report += f"\n\n---\n\n*Generated on {timestamp}. Verify important claims against the original sources.*"

    return report, summary, source_markdown


def build_interface():
    with gr.Blocks(title="AI Research Assistant", theme=gr.themes.Soft()) as demo:
        gr.Markdown(
            """
            # 🔎 AI Research Assistant
            **Three-agent research workflow:** Web Researcher → Findings Summarizer → Report Writer

            Enter a research question to search the web, synthesize findings, and generate
            a structured Markdown report with source links.
            """
        )

        with gr.Row():
            with gr.Column(scale=2):
                topic = gr.Textbox(
                    label="Research topic or question",
                    placeholder="Example: How are generative AI systems being used in healthcare in 2025–2026?",
                    lines=3,
                )
                with gr.Row():
                    max_results = gr.Slider(
                        minimum=3, maximum=10, value=6, step=1,
                        label="Number of web sources",
                    )
                    report_length = gr.Dropdown(
                        choices=["Concise", "Standard", "Detailed"],
                        value="Standard",
                        label="Report depth",
                    )
                model = gr.Textbox(
                    label="OpenAI model",
                    value=OPENAI_MODEL_DEFAULT,
                    info="Change this to a model enabled for your API account.",
                )
                run_button = gr.Button("🚀 Research and generate report", variant="primary")

            with gr.Column(scale=1):
                openai_key = gr.Textbox(
                    label="OpenAI API key",
                    value=os.getenv("OPENAI_API_KEY", ""),
                    type="password",
                )
                tavily_key = gr.Textbox(
                    label="Tavily API key",
                    value=os.getenv("TAVILY_API_KEY", ""),
                    type="password",
                )
                gr.Markdown(
                    "Keys can also be stored in a local `.env` file. "
                    "Never commit real keys to Git."
                )

        with gr.Tabs():
            with gr.Tab("📄 Research Report"):
                report_output = gr.Markdown(label="Generated report")
            with gr.Tab("🧠 Research Summary"):
                summary_output = gr.Markdown(label="Summarized findings")
            with gr.Tab("🔗 Sources"):
                sources_output = gr.Markdown(label="Web sources")

        run_button.click(
            fn=run_research,
            inputs=[
                topic, openai_key, tavily_key, model,
                max_results, report_length,
            ],
            outputs=[report_output, summary_output, sources_output],
        )

        gr.Markdown(
            """
            ---
            **Note:** This is an assisted research tool, not a substitute for expert review.
            Search results may be incomplete or outdated. Open the source links and verify
            important claims before using the report.
            """
        )

    return demo


if __name__ == "__main__":
    app = build_interface()
    app.queue()
    app.launch()
