# AI Research Assistant — Week 3

A multi-agent AI research assistant built with Python, OpenAI, Tavily Search, and Gradio.

The workflow uses three specialized agents:

1. **Web Research Agent** — searches the public web and collects titles, URLs, and snippets.
2. **Findings Summarizer Agent** — synthesizes the search results, identifies themes and evidence gaps, and preserves source labels.
3. **Research Report Writer Agent** — turns the summary into a structured Markdown research report with source references.

## Features

- Gradio web interface.
- Multi-agent, sequential workflow with three distinct agent roles.
- Web search powered by Tavily.
- OpenAI-powered summarization and report generation.
- Configurable number of search results.
- Concise, standard, or detailed report depth.
- Separate tabs for report, research summary, and sources.
- Clickable source URLs.
- API keys entered in the UI or loaded from `.env`.

## Architecture

```text
User research question
        |
        v
Gradio interface
        |
        v
Agent 1: Web Research Agent
(Tavily Search API)
        |
        | Titles, URLs, search snippets
        v
Agent 2: Findings Summarizer Agent
(OpenAI)
        |
        | Findings, themes, evidence gaps
        v
Agent 3: Research Report Writer Agent
(OpenAI)
        |
        v
Structured Markdown report
        |
        v
Gradio tabs: Report | Summary | Sources
```

## Project structure

```text
ai-research-assistant-week3/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
└── README.md
```

## Requirements

- Python 3.10 or newer
- OpenAI API key
- Tavily API key
- Internet connection

API usage may incur charges. A ChatGPT subscription does not automatically include OpenAI API credits. Check Tavily's current plan and usage limits.

Get API keys:
- OpenAI: https://platform.openai.com/api-keys
- Tavily: https://app.tavily.com/home

## Setup

### 1. Clone the repository

```bash
git clone <your-github-repository-url>
cd ai-research-assistant-week3
```

### 2. Create and activate a virtual environment

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

macOS / Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Configure API keys

Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

macOS / Linux:

```bash
cp .env.example .env
```

Edit `.env`:

```env
OPENAI_API_KEY=your_real_openai_key
TAVILY_API_KEY=your_real_tavily_key
```

Never commit `.env` or expose your API keys. The `.gitignore` file excludes it.

### 5. Run the app

```bash
python app.py
```

Open the local Gradio URL printed in the terminal, usually `http://127.0.0.1:7860`.

## How to use

1. Enter your research topic or question.
2. Enter OpenAI and Tavily API keys in the interface or configure `.env`.
3. Select the number of web sources.
4. Select report depth.
5. Confirm the OpenAI model is available to your account.
6. Click **Research and generate report**.
7. Review the report, summary, and source links in their tabs.
8. Open the source links to verify important claims.

## Example topics for testing

- Benefits and risks of AI agents in enterprise automation.
- Recent applications of digital twins in industrial robotics.
- How retrieval-augmented generation reduces hallucinations in knowledge systems.
- Trends in Microsoft Power Platform and low-code automation.

## Important limitations

- The search agent receives web search snippets, not necessarily the full text of every article.
- Search coverage depends on Tavily and the query.
- The agents are orchestrated sequentially in one Python process; they are specialized prompt-driven agents, not autonomous background services.
- Source labels link claims to retrieved search results, but citations are not proof that every statement is correct.
- Always verify high-impact facts and open original sources.
- Do not use the tool to process confidential company information unless your organization permits it.

## Troubleshooting

- **Invalid OpenAI key:** Verify the key and API account billing.
- **Invalid Tavily key:** Verify the key in your Tavily dashboard.
- **No search results:** Broaden the topic or reduce overly restrictive wording.
- **Model not found:** Enter a model name available to your API account.
- **Rate limit / quota:** Check provider usage limits and billing.
- **Module not found:** Activate `.venv` and reinstall requirements.

## GitHub submission

```bash
git status
git add app.py requirements.txt README.md .env.example .gitignore
git commit -m "Week 3 - Build multi-agent AI research assistant with Gradio"
git push
```

Do not commit `.env`, API keys, or private research material.

## Suggested screenshots for submission

1. Gradio interface with a research question entered.
2. Research report output.
3. Summarized findings tab.
4. Sources tab showing clickable source URLs.
